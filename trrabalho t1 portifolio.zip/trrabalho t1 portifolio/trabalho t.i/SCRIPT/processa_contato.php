<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "portfolio";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
  die("Erro de conexão: " . $conn->connect_error);
}

$nome = $_POST['nome'];
$email = $_POST['email'];
$mensagem = $_POST['mensagem'];

$sql = "INSERT INTO contatos (nome, email, mensagem) VALUES ('$nome', '$email', '$mensagem')";
$conn->query($sql);

echo "<script>alert('Mensagem enviada com sucesso!'); window.location.href='index.html';</script>";

$conn->close();
?>
